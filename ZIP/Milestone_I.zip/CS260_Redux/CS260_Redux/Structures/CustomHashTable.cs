﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS260_Redux.Structures
{
    public class CustomHashTable<T>
    {
        int _DEFAULT_SIZE = 500;
        T[] _List;
        public CustomHashTable()
        {
            _List = new T[_DEFAULT_SIZE];
        }

        /// <summary>
        /// Insert a record into the hash table
        /// </summary>
        /// <param name="key"></param>
        /// <param name="data"></param>
        public void Insert(int key, T data)
        {
            // Get an Index
            int index = Hash(key);
            // Store the object
            if (index < _DEFAULT_SIZE && index >= 0)
                _List[index] = data;
            else
                throw new Exception("Invalid Index");
        }

       
        public T Search(T data, out int index)
        {
            // find the key in (inex)th list
            for (int i = 0; i < _DEFAULT_SIZE; i++)
            {
                // Found the object
                if (_List[i].Equals(data))
                {
                    index = i;
                    return _List[i];
                }
            }
            // Didn't find the object
            index = -1;
            return default(T);
        }


        /// <summary>
        /// Removes a record from the hash table
        /// </summary>
        /// <param name="key"></param>
        public void Remove(T data)
        {
            // find the key in (inex)th list
            T newData = Search(data, out int index);
            if (index != -1)
                _List[index] = default(T);
        }

        /// <summary>
        /// Prints the list
        /// </summary>
        public void PrintAll()
        {
            // Implement logic to print all bids
            for (int i = 0; i < _DEFAULT_SIZE; i++)
            {
                if (_List[i] != null)
                    Console.WriteLine($"{i} --> {_List[i].ToString()}"); // Write Out Values
                else
                    Console.WriteLine($"{i} --> [ ]");
            }
        }

        /*
         *  Privates 
         */

        int Hash(int key)
        {
            // Implement logic to calculate a hash value
            return (key % _DEFAULT_SIZE);
        }
    }
}
