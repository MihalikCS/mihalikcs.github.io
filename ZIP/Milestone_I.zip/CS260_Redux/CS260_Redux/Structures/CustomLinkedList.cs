﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS260_Redux.Structures
{
    public class CustomLinkedList<T>
    {
        LLNode<T> _Head;
        LLNode<T> _Tail;
        int _Size;

        public CustomLinkedList()
        {
            _Head = null;
            _Tail = null;
            _Size = 0;
        }

        // Append to the back of the node
        public void Append(T data)
        {
            // Create node
            LLNode<T> node = new LLNode<T>(data);

            // Check if no tail
            if (_Head == null)
            {
                // Create a new list
                _Head = node;
                _Tail = node;
            }
            else
            {
                // Append to the end of the list
                _Tail.setNext(node);
                _Tail = node;
            }

            // Increase the size
            _Size += 1;
        }

        // Prepent to the start of the list
        public void Prepend(T data)
        {
            // Init
            LLNode<T> temp = null;
            LLNode<T> node = new LLNode<T>(data);

            // Check head pointer
            if (_Head == null)
            {
                _Head = node;
                _Tail = node;
            }
            else
            {
                temp = _Head;
                _Head = node;
                _Head.setNext(temp);
            }

            // Increase the size
            _Size += 1;
        }

        public void Remove(T data)
        {
            // Init
            LLNode<T> curr = null;
            LLNode<T> prev = null;

            // Logic start
            curr = _Head;
            while (curr != null)
            {
                T currData = curr.getData();
                if (currData.Equals(data))
                {
                    // Special functions for short list
                    if (curr == _Head)
                        _Head = curr.getNext();
                    if (curr == _Tail)
                        _Tail = prev;
                    // Remove element
                    prev.setNext(curr.getNext());
                    // Remove size
                    _Size -= 1;
                }
                // Progress Forwards
                prev = curr;
                curr = curr.getNext();
            }
        }

        // Search function
        public T Search(T data)
        {
            return default(T);
        }

        public void PrintAll()
        {
            LLNode<T> node = _Head;
            while (node.getNext() != null)
            {
                Console.WriteLine("\nNode");
                Console.WriteLine("------------");
                Console.WriteLine($"Next: {node.getNext()}");
                Console.WriteLine($"Prev: {node.getPrevious()}");
            }
        }

        // Returns the size of the list
        public int Size()
        {
            return _Size;
        }
    }

    internal class LLNode<T>
    {
        T _Data;
        LLNode<T> _Prev;
        LLNode<T> _Next;

        public LLNode(T data)
        {
            _Data = data;
            _Prev = null;
            _Next = null;
        }

        // Setters
        public void setPrevious(LLNode<T> prev)
        {
            _Prev = prev;
        }

        public void setNext(LLNode<T> next)
        {
            _Next = next;
        }

        public void setData(T data)
        {
            _Data = data;
        }

        // Getters
        public LLNode<T> getPrevious()
        {
            return _Prev;
        }

        public LLNode<T> getNext()
        {
            return _Next;
        }

        public T getData()
        {
            return _Data;
        }
    }
}
