﻿using CS260_Redux.Generator;
using CS260_Redux.Model;
using CS260_Redux.Structures;
using System;
using System.Collections.Generic;

namespace CS260_Redux
{
    class Program
    {
        static int _MAX_OBJECT_SIZE = 500, _EXIT_NUM = 6;
        const string _TEST_DATA_FILENAME = "./TestData.json";
        static List<FileDTO> _TEST_DATA_LIST = new List<FileDTO>();

        static void Main(string[] args)
        {
            // Init
            int selection = -1;
            // Logic
            while (selection != _EXIT_NUM)
            {
                // Call DisplayMenu function
                selection = DisplayMenu();

                // Fall int code blocks
                switch (selection)
                {
                    case 1:
                        Console.WriteLine("\nStarting Generate Data subroutine...");
                        DataGenerator gen = new DataGenerator(_MAX_OBJECT_SIZE);
                        gen.GenerateData();
                        gen.WriteFile(_TEST_DATA_FILENAME);
                        break;
                        
                    case 2:
                        Console.WriteLine("\nStarting Load Data subroutine...");
                        DataLoader loader = new DataLoader(_TEST_DATA_FILENAME);
                        _TEST_DATA_LIST = loader.getTestData();
                        break;

                    case 3:
                        Console.WriteLine("\nStarting Create Linked List subroutine...");
                        // Create a Linked List
                        Console.WriteLine("-- Creating linked list...");
                        CustomLinkedList<FileDTO> linkedList = new CustomLinkedList<FileDTO>();
                        LoadLinkedList(linkedList);

                        // Prepend a value
                        linkedList.Prepend(new FileDTO(30, "George", "1234 Dog Street", 8675309));

                        // Print the list
                        linkedList.PrintAll();

                        // Prepend a value
                        linkedList.Remove(new FileDTO(30, "George", "1234 Dog Street", 8675309));

                        // Append a Value
                        linkedList.Append(new FileDTO(30, "George", "1234 Dog Street", 8675309));

                        // Print the list
                        linkedList.PrintAll();
                        break;

                    case 4:
                        Console.WriteLine("\nStarting Create Binary Tree subroutine...");
                        // Create a Binary Tree
                        Console.WriteLine("-- Creating Binary Tree...");
                        CustomBinaryTree<FileDTO> binaryTree = new CustomBinaryTree<FileDTO>();
                        LoadBinaryTree(binaryTree);

                        // Print Sorts
                        Console.WriteLine("\nIn-Order Sort");
                        binaryTree.InOrder();
                        // PreOrder
                        Console.WriteLine("\nPre-Order Sort");
                        binaryTree.PreOrder();
                        // Post Order
                        Console.WriteLine("\nPost-Order Sort");
                        binaryTree.PostOrder();
                        
                        // Remote an key
                        binaryTree.Remove(5);
                        break;

                    case 5:
                        Console.WriteLine("\nStarting Create Hash Table subroutine...");
                        // Create a Hash Table
                        Console.WriteLine("-- Creating Binary Tree...");
                        CustomHashTable<FileDTO> hashTable = new CustomHashTable<FileDTO>();
                        LoadHashTable(hashTable);


                        hashTable.PrintAll();
                        break;

                    default:
                        break;
                }
            }
        }

        static int DisplayMenu()
        {
            // Init
            int selection = -1;
            bool isValidSelection = false;

            // Write Menu Options
            Console.WriteLine("\n1. Generate Test Data");
            Console.WriteLine("2. Load Test Data");
            Console.WriteLine("3. Create Linked List");
            Console.WriteLine("4. Create Binary Tree");
            Console.WriteLine("5. Create HashTable");
            Console.WriteLine("6. Exit\n");

            // Get Selection
            Console.Write("Enter your selection: ");
            var input = Console.ReadLine();

            // Loop until valid
            while (!isValidSelection)
            {
                // Try to convert number
                var conversionSuccessful = int.TryParse(input, out selection);
                // Check if the number brought in is actually a number
                if (conversionSuccessful)
                {
                    // Check Range
                    if (selection >= 0 && selection <= 6)
                    {
                        // Break the loop
                        isValidSelection = true;
                    }
                    else
                    {
                        // Invalid Number, try again
                        Console.WriteLine("Invalid selection item.");
                        Console.Write("Enter your selection: ");
                        input = Console.ReadLine();
                    }
                }
                else
                {
                    // Invalid Number, try again
                    Console.WriteLine("Invalid number entered.");
                    Console.Write("Enter your selection: ");
                    input = Console.ReadLine();
                }
            }
            // Return the selection
            return selection;
        }

        /*
         * Private Helpers
         */
        private static bool CheckTestDataLoaded()
        {
            // Init
            bool IsTestDataLoaded = true;
            // Check for condition
            if (_TEST_DATA_LIST.Count <= 0)
            {
                IsTestDataLoaded = false;
                Console.WriteLine("-- Appears no test data is loaded. Load test data and try again.");
            }
            // Return
            return IsTestDataLoaded;
        }

        private static void LoadLinkedList(CustomLinkedList<FileDTO> list)
        {
            // Return to Menu if data isnt loaded
            if (!CheckTestDataLoaded())
                return;

            // Add Nodes
            foreach (var obj in _TEST_DATA_LIST)
            {
                list.Append(obj);
            }
        }

        private static void LoadBinaryTree(CustomBinaryTree<FileDTO> tree)
        {
            // Return to Menu if data isnt loaded
            if (!CheckTestDataLoaded())
                return;

            // Add Nodes
            foreach (var obj in _TEST_DATA_LIST)
            {
                tree.Insert(obj.key, obj);
            }
        }

        private static void LoadHashTable(CustomHashTable<FileDTO> table)
        {
            // Return to Menu if data isnt loaded
            if (!CheckTestDataLoaded())
                return;

            // Add Nodes
            foreach (var obj in _TEST_DATA_LIST)
            {
                table.Insert(obj.key, obj);
            }
        }
    }
}
