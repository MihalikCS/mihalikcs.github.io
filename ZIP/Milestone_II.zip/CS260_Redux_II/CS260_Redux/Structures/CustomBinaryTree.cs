﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS260_Redux.Structures
{
    public class CustomBinaryTree<T>
    {
        BTNode<T> _Root;

        public CustomBinaryTree()
        {
            _Root = null; 
        }

        public void Insert(int key, T data)
        {
            if(_Root == null)
            {
                _Root = new BTNode<T>(key, data);
            }
            else
            {
                // Add Node using the function
                AddNode(_Root, data, key);
            }
        }

        /// <summary>
        /// Removes a node from the tree
        /// </summary>
        /// <param name="key">Key to remove</param>
        public void Remove(int key)
        {
            // Implement removing a bid from the tree
            if (_Root != null)
            {
                BTNode<T> foundNode = SearchNode(key);
                BTNode<T> removedNode = RemoveNode(foundNode, key);
                Console.WriteLine($"Removed Node {removedNode.getKey()}");
            }
        }

        // Performs an InOrder sort on the tree
        public void InOrder()
        {
            // Print the tree InOrder
            if (_Root != null)
                InOrderSort(_Root);
        }

        // Performs an PreOrder sort on the tree
        public void PreOrder()
        {
            // Print the tree InOrder
            if (_Root != null)
                PreOrderSort(_Root);
        }

        // Performs an PostOrder sort on the tree
        public void PostOrder()
        {
            // Print the tree InOrder
            if (_Root != null)
                PostOrderSort(_Root);
        }

        /*
         * Privates
         */

        void AddNode(BTNode<T> node, T data, int key)
        {
            // Check if node is empty
            if (node.getKey() < key)
                if (node.getLeft() == null)
                    node.setLeft(new BTNode<T>(key, data));
                else
                    AddNode(node.getLeft(), data, key);
            else if (node.getKey() > key)
                if (node.getRight() == null)
                    node.setRight(new BTNode<T>(key, data));
                else
                    AddNode(node.getRight(), data, key);
        }

        BTNode<T> RemoveNode(BTNode<T> node, int key)
        {
            // Default 
            if (node == null) return node;
            // If the key is smaller, go left 
            if (key < node.getKey())
                node.setLeft(RemoveNode(node.getLeft(), key));
            // If the key is greater, go right
            else if (key > node.getKey())
                node.setRight(RemoveNode(node.getRight(), key));
            // We found the node to be deleted
            else
            {
                // node with only one child or no child 
                if (node.getLeft() == null)
                    return node.getRight();
                else if (node.getRight() == null)
                    return node.getLeft();
                // node with two children
                BTNode<T> tmp = MinValueNode(node.getRight());
                // Copy the inorder successor's content to this node 
                node.setKey(tmp.getKey());
                // Delete the inorder successor 
                node.setRight(RemoveNode(node.getRight(),tmp.getKey()));
            }
            return node;
        }

        /// <summary>
        /// Helper to find the node with the smallest value
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        BTNode<T> MinValueNode(BTNode<T> node)
        {
            // Set empty node
            BTNode<T> curr = null;
            // Walk the tree
            while (curr != null && curr.getLeft() != null)
            {
                // Keep progressing to the left
                curr = curr.getLeft();
            }
            return curr;
        }

        /// <summary>
        /// Searches the tree for a node with the specified key
        /// </summary>
        /// <param name="key">The id in which to locate the node</param>
        /// <returns></returns>
        BTNode<T> SearchNode(int key)
        {
            // Init
            BTNode<T> curr = _Root;
            // Logic
            while (curr.getKey() != key)
            {
                // go to the left
                if (curr.getKey() < key)
                    curr = curr.getLeft();
                else
                    curr = curr.getRight();

                // Cant find a target
                if (curr == null)
                    return null;
            }
            return curr;
        }

        /// <summary>
        /// Performs an InoOrder sort
        /// </summary>
        /// <param name="node"></param>
        void InOrderSort(BTNode<T> node)
        {
            if (node != null)
            {
                InOrderSort(node.getLeft());
                Console.Write($"{node.getKey()} ");
                InOrderSort(node.getRight());
            }
        }

        /// <summary>
        /// Performs a recursive preorder sort
        /// </summary>
        /// <param name="node"></param>
        void PreOrderSort(BTNode<T> node)
        {
            if (node != null)
            {
                Console.Write($"{node.getKey()} ");
                PreOrderSort(node.getLeft());
                PreOrderSort(node.getRight());
            }
        }

        /// <summary>
        /// Performs a recursive postorder sort
        /// </summary>
        /// <param name="node"></param>
        void PostOrderSort(BTNode<T> node)
        {
            if (node != null)
            {
                PreOrderSort(node.getLeft());
                PreOrderSort(node.getRight());
                Console.Write($"{node.getKey()} ");
            }
        }
    }

    internal class BTNode<T>
    {
        int _Key;
        BTNode<T> _Left, _Right;
        T _Data;

        public BTNode()
        {
            _Left = null;
            _Right = null;
            _Data = default(T);
        }

        public BTNode(int nodeKey)
        {
            _Key = nodeKey;
            _Left = null;
            _Right = null;
            _Data = default(T);
        }

        public BTNode(int nodeKey, T data)
        {
            _Key = nodeKey;
            _Left = null;
            _Right = null;
            _Data = data;
        }

        // Setters
        public void setLeft(BTNode<T> left)
        {
            _Left = left;
        }

        public void setRight(BTNode<T> right)
        {
            _Right = right;
        }

        public void setData(T data)
        {
            _Data = data;
        }
        public void setKey(int key)
        {
            _Key = key;
        }

        // Getters
        public BTNode<T> getLeft()
        {
            return _Left;
        }

        public BTNode<T> getRight()
        {
            return _Right;
        }

        public T getData()
        {
            return _Data;
        }

        public int getKey()
        {
            return _Key;
        }
    }
}
