﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS260_Redux.Structures
{
    public class CustomLinkedList<T>
    {
        LLNode<T> _Head;
        LLNode<T> _Tail;
        int _Size;

        public CustomLinkedList()
        {
            _Head = null;
            _Tail = null;
            _Size = 0;
        }

        /// <summary>
        /// Add node to the end of the linked list
        /// </summary>
        /// <param name="data"></param>
        public void Append(T data)
        {
            // Create node
            LLNode<T> node = new LLNode<T>(data);

            // Check if no tail
            if (_Head == null)
            {
                // Create a new list
                _Head = node;
                _Tail = node;
            }
            else
            {
                // Append to the end of the list
                _Tail.setNext(node);
                node.setPrevious(_Tail);
                _Tail = node;
            }

            // Increase the size
            _Size += 1;
        }

        /// <summary>
        /// Adds element to start of double linked list
        /// </summary>
        /// <param name="data"></param>
        public void Prepend(T data)
        {
            // Init
            LLNode<T> temp = null;
            LLNode<T> node = new LLNode<T>(data);

            // Check head pointer
            if (_Head == null)
            {
                _Head = node;
                _Tail = node;
            }
            else
            {
                temp = _Head;
                _Head = node;
                _Head.setNext(temp);
                temp.setPrevious(_Head);
            }

            // Increase the size
            _Size += 1;
        }

        /// <summary>
        /// Support the removal of nodes
        /// </summary>
        /// <param name="data"></param>
        public void Remove(T data)
        {
            // Init
            LLNode<T> temp = null;
            LLNode<T> curr = null;
            LLNode<T> prev = null;

            // Logic start
            curr = _Head;
            while (curr != null)
            {
                T currData = curr.getData();
                if (currData.Equals(data))
                {
                    // Special functions for short list
                    if (curr == _Head)
                    {
                        // Reset the head
                        _Head = curr.getNext();
                        _Head.setPrevious(null);
                    }
                    if (curr == _Tail)
                    {
                        // Clear the pointer behind and reset tail
                        prev.setNext(null);
                        _Tail = prev;
                    }
                    // Remove element
                    temp = curr.getNext();
                    temp.setPrevious(prev);
                    prev.setNext(temp);
                    // Remove size
                    _Size -= 1;
                }
                // Progress Forwards
                prev = curr;
                curr = curr.getNext();
            }
        }

        // Search function
        LLNode<T> Search(T data)
        {
            // Init
            LLNode<T> curr = null;
            // Logic start
            curr = _Head;
            while (curr != null)
            {
                T currData = curr.getData();
                if (currData.Equals(data))
                {
                    return curr;
                }
            }

            // default return
            return null;
        }

        /// <summary>
        /// Prints the nodes
        /// </summary>
        public void PrintAll()
        {
            // Init
            LLNode<T> node = _Head;

            // Traverse
            while (node != null)
            {
                Console.WriteLine("\nNode");
                Console.WriteLine("------------");
                // Node Next
                if (node.getNext() != null)
                {
                    Console.Write($"Next: ");
                    PrintOne(node.getNext().getData());
                }
                else
                    Console.Write($"Next: {node.getNext()}");

                // Space
                Console.WriteLine();

                // Node Prev
                if (node.getPrevious() != null)
                {
                    Console.Write($"Prev: ");
                    PrintOne(node.getPrevious().getData());
                }
                else
                    Console.Write($"Prev: {node.getPrevious()}");

                // Set the next ref
                node = node.getNext();
            }
        }

        private void PrintOne(T obj)
        {
            // Get Props
            var props = typeof(T).GetProperties();
            foreach (var prop in props)
            {
                Console.Write($"{prop.Name}: ");
                Console.Write($"{prop.GetValue(obj)}\t");
            }
        }

        // Returns the size of the list
        public int Size()
        {
            return _Size;
        }
    }

    internal class LLNode<T>
    {
        T _Data;
        LLNode<T> _Prev;
        LLNode<T> _Next;

        public LLNode(T data)
        {
            _Data = data;
            _Prev = null;
            _Next = null;
        }

        // Setters
        public void setPrevious(LLNode<T> prev)
        {
            _Prev = prev;
        }

        public void setNext(LLNode<T> next)
        {
            _Next = next;
        }

        public void setData(T data)
        {
            _Data = data;
        }

        // Getters
        public LLNode<T> getPrevious()
        {
            return _Prev;
        }

        public LLNode<T> getNext()
        {
            return _Next;
        }

        public T getData()
        {
            return _Data;
        }
    }
}
